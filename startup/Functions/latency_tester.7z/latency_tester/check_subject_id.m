function valid_id = check_subject_id(subject_id)

valid_id = false;

sub_id_check = (contains(subject_id,{'S','T'}) && length(subject_id) == 8) && ...
    sum(uint8(subject_id)>= 48 & uint8(subject_id)<=57) == 6;

if sub_id_check
    valid_id = true;
elseif contains(subject_id,'test')
    valid_id = true;
elseif contains(subject_id,'DTM')
    valid_id = true;
end
