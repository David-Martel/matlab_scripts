function audio_device_id = get_audio_device()

audio_devs = audiodevinfo;
output_devs = audio_devs.output;


output_names = {output_devs(:).Name};
output_ids = [output_devs(:).ID];

prompt = '';
for id_iter = 1:length(output_ids)
    dev_str = ['ID: ' num2str(output_ids(id_iter))  ', Device: ' output_names{id_iter} newline newline];
    
    if id_iter == 1
        dev_str = ['(Default) ' dev_str];
    elseif id_iter == length(output_ids)
        dev_str((end-2):end) = [];
    end
    prompt = [prompt dev_str];
end

audio_device_id = 0;
subject_id_counter = 0;
prompt = {prompt};
dlgtitle = 'Get Audio Device ID';

default_id = output_ids(1);

def_input = {num2str(default_id)};
input_dims = [1 100];

while ~audio_device_id && subject_id_counter <= 3
    audio_device_id = inputdlg(prompt,dlgtitle,input_dims,def_input);
    
    if isempty(audio_device_id)
        uiwait(msgbox('Default chosen'))
        audio_device_id = default_id;
    else
        audio_device_id = str2double(audio_device_id{:});
    end
    
    if ismember(audio_device_id,output_ids)
        break;
    else
        uiwait(msgbox('Bad ID; Choose again'));
        subject_id_counter = subject_id_counter + 1;
    end
    
end

if subject_id_counter > 3
    
    uiwait(msgbox('Default chosen'))
    audio_device_id = default_id;
    
end