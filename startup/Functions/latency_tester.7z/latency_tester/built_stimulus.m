function [trial_sound,rand_start_times,stim_time,sound_on] = built_stimulus(Fs,stim_dur,window_ramp,...
    trial_period,offset,num_trial,varargin)

%% build stimulus
% Fs = 48000;
% stim_dur = 400/1000;
% window_ramp = 40/1000; %)--> Divide by 2 to get actual rise/fall times

plot_enable = false;
if any(contains(varargin,'plot'))
    plot_enable = true;
end


noise_sound = randn(Fs.*stim_dur,1,'double');
noise_sound = noise_sound./max(abs(noise_sound(:)));

noise_samps = length(noise_sound);

stim_time = (0:(noise_samps-1))./Fs;


window_func = tukeywin(noise_samps,window_ramp/stim_dur/2);
noise_sound = window_func.*noise_sound;

if plot_enable
    f = figure;
    clf(f)
    subplot(1,2,1)
    hold on
    
    plot(stim_time.*1000,window_func,'b')
    plot(stim_time.*1000,noise_sound,'r')
    xlabel('Time (ms)')
    ylabel('Amplitude')
    
    title('Sound Pulse')
    
end

%% set up distribution of interpulse intervals

trial_sound = zeros(trial_period.*Fs,1,'double');

possible_time = offset+1:(trial_period-2*offset);

rand_start_times = randsample(possible_time,num_trial,false); %offset+randi(trial_period-offset,num_trial,1); %[2 5 8];
rand_start_times = sort(rand_start_times,'ascend');


%% build sound stimulus
%background noise level? Chen et al paper for reference
sound_on = false(size(trial_sound));
time_vec = 1:length(trial_sound);
if isrow(time_vec)
    time_vec = time_vec';
end

for trial_iter = 1:length(rand_start_times)
    sound_idx = 1:noise_samps;
    sound_idx = sound_idx + Fs*rand_start_times(trial_iter);
    
    sound_on = sound_on | (time_vec>=min(sound_idx) & time_vec<max(sound_idx));
    trial_sound(sound_idx) = noise_sound;
end

% plot trial sound
if plot_enable
    
    subplot(1,2,2)
    hold on
    
    plot(time_vec./Fs,trial_sound,'b')
    plot(time_vec./Fs,sound_on,'r')
    
    xlabel('Time (sec)')
    ylabel('Signal (arb)')
    title('Stimulus Train')
end
