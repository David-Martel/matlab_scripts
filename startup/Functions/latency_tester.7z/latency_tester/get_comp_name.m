function [compname] = get_comp_name()

[success,compname] = system('hostname');

if ~success
    compname(end) = [];
else
    compname = 'Error';
end





