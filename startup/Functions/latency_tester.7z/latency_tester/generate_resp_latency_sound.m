clear
clc
close all


base_dir = pwd;
local_files = dir(base_dir);

local_file_list = {local_files(:).name};

proper_run_dir = contains(local_file_list,'nircmd.exe');
if ~any(proper_run_dir)
    uiwait(msgbox('Bad initial directory'),2);
    return
end

data_dir = fullfile(base_dir,'data');
if ~exist(data_dir,'dir')
    mkdir(data_dir);
    addpath(genpath(data_dir));
end

error_dir = fullfile(base_dir,'error');
if ~exist(error_dir,'dir')
    mkdir(error_dir);
    addpath(genpath(error_dir));
end

%% Get subject id
input_name_good = false;

[compname] = get_comp_name();

if contains(compname,'DTM-')
    input_name_good = true;
    subject_id = 'DTM';
end

subject_id_counter = 0;
prompt = {'Input Subject ID'};
dlgtitle = 'Subject ID';
def_input = {'S###T###'};
input_dims = [1 20];

while ~input_name_good && subject_id_counter <= 3
    
    
    subject_id = inputdlg(prompt,dlgtitle,input_dims,def_input);
    subject_id = subject_id{:};
    
    if check_subject_id(subject_id)
        input_name_good = true;
    else
        subject_id_counter = subject_id_counter + 1;
        uiwait(msgbox('Bad subject id; try again'));
    end
    
end

if subject_id_counter > 4
    uiwait(msgbox('Ur a derp brah, no test for u'));
    return;
end

subject_dir = fullfile(data_dir,subject_id);
if ~exist(subject_dir,'dir')
    mkdir(subject_dir);
end

%% gets experiment time
exp_time = datestr(now);
exp_time = replace(exp_time,{':',' '},{'-','_'});

test_time_parts = strsplit(exp_time,'_');
test_date = test_time_parts{1};
test_time = test_time_parts{2};

save_file = fullfile(subject_dir,[subject_id '_' exp_time '.mat']);
if exist(save_file,'file')
    old_save_file = replace(save_file,'.mat','_old.mat');
    [success] = copyfile(save_file,old_save_file,'f');
    if ~success
        uiwait(msgbox('Error saving data; restart application'));
        return;
    end
end


%% build trial stimulus
Fs = 48000;
stim_dur = 400/1000;
window_ramp = 40/1000; %)--> Divide by 2 to get actual rise/fall times

trial_period = 120; %seconds
offset = 10; %seconds

num_trial = 20;

try
    [trial_sound,rand_start_times] = built_stimulus(Fs,stim_dur,window_ramp,...
        trial_period,offset,num_trial,'plot');
    stim_times = cumsum(rand_start_times);

catch MException
    
    save_file = replace(save_file,{'.mat',subject_dir},{'_ERROR.mat',error_dir});
    save(save_file,'MException')
    uiwait(msgbox('Error building sound; consult engineering'));
    return
    
end

%% Create audioplayer
nbits = 16;
trial_sound = trial_sound./max(abs(trial_sound));
trial_sound = int16(2^(nbits-1).*trial_sound);

%or, one ear vs other ear
num_channel = 2;
trial_sound = repmat(trial_sound,1,num_channel);


db_offset = -30;
inten_scalar = db2mag(db_offset);
trial_sound = trial_sound.*inten_scalar;

%% Select output device

audio_device_id = get_audio_device();

trial_output = audioplayer(trial_sound,Fs,nbits,audio_device_id); %first, set sound level in OS to maximum

%Steps.
%1. find threshold
%2. find

%% image feedback
xsize = 1000;
ysize = 1000;
color = 3;

%----------------------------------------------------------------------
im_red = zeros(xsize,ysize,color,'uint8');
im_red(:,:,1) = 255;

start_plot_opts = {'Font','Arial','AnchorPoint','Center','FontSize',60,...
    'BoxOpacity',0,'BoxColor','white','TextColor',0.6.*[1 1 1]};

start_hold_time = 2;
im_start = insertText(im_red,[xsize/2 ysize/2],...
    ['Start in ' num2str(start_hold_time) ' seconds'],start_plot_opts{:});

im_click = insertText(im_red,[xsize/2 ysize/2],'Click!',start_plot_opts{:});

%----------------------------------------------------------------------
im_green = zeros(xsize,ysize,color,'uint8');
im_green(:,:,2) = 255;

button_plot_opts = {'Font','Arial','AnchorPoint','Center','FontSize',60,...
    'BoxOpacity',0,'BoxColor','white','TextColor',0.6.*[1 1 1]};
im_button = insertText(im_green,[xsize/2 ysize/2],'Click box on sound',...
    start_plot_opts{:});

button_pos = [xsize./2-xsize/20 ysize*.75-ysize/20 xsize/10 ysize/10];
button_rect_opts = {'FilledRectangle',button_pos,...
    'Color','white','Opacity',1};
im_button = insertShape(im_button,button_rect_opts{:});

%-----------------------------------------------------------------------
im_yellow = zeros(xsize,ysize,color,'uint8');
im_yellow(:,:,[1 2]) = 255;

im_timeout = insertText(im_yellow,[xsize/2 ysize/2],'Timeout',...
    button_plot_opts{:});

im_done = insertText(im_yellow,[xsize/2 ysize/2],['Finished: ' num2str(db_offset) 'dB re Max'],...
    button_plot_opts{:});

im_early = insertText(im_yellow,[xsize/2 ysize/2],['Early!'],...
    button_plot_opts{:});


%% plot visual feedback
if ~exist('hFig','var')
    hFig = figure();
end
clf(hFig)
set(hFig,'menubar','none');
set(hFig,'NumberTitle','off');
hAx = gca(hFig);
xlim([0,xsize]); ylim([0,ysize]);
fig_handle = imshow(im_start,[],'Parent',hAx,'border','tight');
drawnow;

level = 1.0; %standardize output as much as possible
[success,response] = set_system_volume(base_dir,level);
if success
    uiwait(msgbox(['Error setting system volume:' response]));
    return;
end

rec_data = nan(num_trial,1);
trial_iter = 1;
timeout_size = 1;
click_iter = 1;

trial_delay_store = nan(4*num_trial,1);
click_time_store = nan(4*num_trial,1);
%disp('Starting in 2 seconds')
pause(start_hold_time);

try
    play(trial_output)
    %THings to figure out:
    start_time = tic;
    while isplaying(trial_output) && trial_iter <= num_trial
        
        
        set(fig_handle,'CData',im_button);
        drawnow;
        cur_time = toc(start_time);
        
        next_trial_time = rand_start_times(trial_iter);
        next_trial_delay = next_trial_time - cur_time;
        
        trial_delay_store(click_iter) = next_trial_delay;
        
        %disp(['Trial ' num2str(trial_iter) newline 'Click  on sound']);
        %button = waitforbuttonpress;
        
        %wait for button press, and timeout on failure
        timeout_time = floor((next_trial_delay+timeout_size)*1000)/1000;
        click_loc = mouseinput_timeout(timeout_time, hAx);
        click_time = toc(start_time);
        
        %state machine of resposnes
        if ~isempty(click_loc)
            
            if click_time-cur_time < next_trial_delay %false positive
                im_plot = im_early; 
                click_iter = click_iter + 1;
                pause_time = 0.1;
                click_time_store(click_iter) = click_time; 
            else
                rec_data(trial_iter) = click_time; %true positive
                click_time_store(click_iter) = click_time;
                
                im_plot = im_click; 
                trial_iter = trial_iter + 1;
                click_iter = click_iter + 1;
                pause_time = 0.5;
            end
        else
            %disp('timeout');
            im_plot = im_timeout; %false negative
            trial_iter = trial_iter + 1;
            pause_time = 0.25;
        end
       
       set(fig_handle,'CData',im_plot);
       drawnow;  
       pause(pause_time);
       
    end
catch MException
    
    stop(trial_output);
    error_message = strcat(MException(:).message,newline);
    
    uiwait(msgbox(['Error during playback: ' newline error_message]),2);
    
end

level = 0.0; %standardize output as much as possible
success = set_system_volume(base_dir,level);

set(fig_handle,'CData',im_done);
drawnow;

%number of clicks
click_time_store(click_iter:end) = [];
trial_delay_store(click_iter:end) = [];

%figure this out better for derp cases
if length(rec_data) == length(rand_start_times)
    latencies = rec_data-rand_start_times';
else
    latencies = [];
end


data_store = struct;
data_store(1).rec_data = rec_data;
data_store(1).stim_times = rand_start_times';
data_store(1).latencies = latencies;
data_store(1).stim_times = stim_times;
data_store(1).db_offset = db_offset;
data_store(1).exp_time = exp_time;
data_store(1).ramp_time = window_ramp;
data_store(1).stim_dur = stim_dur;
data_store(1).test_date = test_date;
data_store(1).test_time = test_time;

save(save_file,'data_store');



%% Plot stuff
if ~exist('results_figure','var')
    results_figure = figure();
end
clf(results_figure);

subplot(1,2,1)
hold on


histogram(latencies,'g')

xlim([0 timeout_size])

xlabel('Time (sec)')
ylabel('Counts')


subplot(1,2,2)
hold on

stem(rand_start_times,ones(size(rand_start_times)),'k*')

stem(click_time_store,ones(size(click_time_store)),'r*')
stem(rec_data,ones(size(rec_data)),'g*')

legend('Pulse Time','False, Positive','True, Positive')




