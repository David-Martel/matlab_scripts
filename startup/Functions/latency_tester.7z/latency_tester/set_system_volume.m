function [success,response] = set_system_volume(base_dir,level)

if level < 0 || level > 1
    success = false;
else
    
    level_str = floor(level.*(2^16));
    
    nircmd = fullfile(base_dir,'nircmd.exe');
    
    sound_level_str = ['"' nircmd '" setsysvolume ' num2str(level_str)];
    [success,response] = system(sound_level_str);
       
end









